# AI Council — V21.15

Six-room council: the user plus five provider seats (ChatGPT, Gemini, Claude, Grok, Kimi).

## V21.15 voice + resilience layer

- Text chat remains the canonical council transport.
- User voice is captured with Streamlit `st.audio_input`.
- The recorded audio is explicitly submitted by the user, then transcribed through the Gemini 3.5 Transcribe API model.
- The resulting transcript enters the exact same five-seat parallel council pipeline as typed text.
- The original voice recording is kept only in the current Streamlit session for playback; it is not written into History metadata.
- Voice storage is bounded to prevent unbounded session-memory growth: at most 10 recent recordings and 40 MB total; each new recording is limited to 8 MB.
- A voice fingerprint is committed only after the council submission path completes, preventing a failed submission from permanently marking the recording as already sent.
- Voice messages can be combined with the folder attachments selected for the same send action.
- AI answers have a browser-side `speechSynthesis` playback control inside each AI room.
- Browser TTS does not call an external API.
- If Gemini transcription is unavailable because of missing credentials, quota, billing, network, or model errors, the app does not pretend to have transcribed the audio and does not fabricate a transcript. The transcription model can be overridden with `GEMINI_TRANSCRIBE_MODEL`; the default is `gemini-3.5-transcribe`.
- Local Engine is never presented as an official transcription or provider response.

## Safety boundaries

- API keys are read from Streamlit Secrets/environment and are never rendered in the UI.
- History stores message metadata and text, not provider credentials.
- Voice audio is session-scoped; it is not serialized into chat History.
- Official/local status is explicit.
- Billing and quota failures are reported rather than hidden.

## Validation

The release must pass the repository unit tests before packaging. The test suite covers attachment limits, provider classification/retry behavior, context isolation, entrypoint compatibility, model configuration, and the voice utility guard paths.

## Important

Passing local tests does not prove that every provider account has valid billing/quota or that every configured model is enabled for that account. Provider health must still be verified from the in-app independent diagnostics.

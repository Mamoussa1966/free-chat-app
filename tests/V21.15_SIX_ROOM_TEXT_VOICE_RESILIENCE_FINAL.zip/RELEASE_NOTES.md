# V21.15 — Six-Room Text + Voice Resilience Hardened

## Scope
- Preserves the six-room architecture: user + ChatGPT/OpenAI + Gemini/Google + Claude/Anthropic + Grok/xAI + Kimi/Moonshot.
- Preserves parallel provider execution, shared context, 1–4 rounds, attachments, explicit Official/Local identity, diagnostics, and session-only history.
- Adds bounded voice-session storage and an 8 MB per-recording cap.
- A voice fingerprint is committed only after the council submission path completes.
- Voice and folder attachments can be submitted together when the send action occurs.
- Gemini voice transcription remains a dedicated official transcription path using `gemini-3.5-transcribe` by default; it never falls back to Local Engine as a fake transcription service.
- Invalid audio payloads and unsafe MIME strings are rejected/sanitized before transcription.

## Validation
- `python -m py_compile *.py tests/*.py` — PASS
- `PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -v` — 25/25 PASS
- ZIP integrity test — PASS

## Important operational boundary
Passing local tests proves code-level invariants only. It does not prove that OpenAI, Gemini, Anthropic, xAI, or Moonshot accounts currently have usable billing/quota/model access. Use the independent in-app diagnostics for live provider health.
